document.addEventListener('DOMContentLoaded', () => {

    
    // 1. AUTHENTICATION ENGINE (Sign In / Sign Up)
    
    const signInBtn = document.getElementById('signInBtn');
    const signUpBtn = document.getElementById('signUpBtn');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');

    function handleAuthAction(actionType) {
        if (!emailInput || !passwordInput) return false;

        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();

        
        if (email === "" || password === "") {
            alert("Please fill out both the email and password fields.");
            return false; 
        }

        
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert("Please enter a valid email address.");
            return false;
        }

        alert(`${actionType} successful!`);
        window.location.href = "udealz1.html"; 
        return true;
    }

    if (signInBtn) {
        signInBtn.addEventListener('click', (event) => {
            event.preventDefault(); 
            handleAuthAction('Sign In');
        });
    }

    if (signUpBtn) {
        signUpBtn.addEventListener('click', (event) => {
            event.preventDefault(); 
            handleAuthAction('Sign Up');
        });
    }

    
    // 2. QUANTITY SELECTOR
    
    const plusBtn = document.getElementById("plusBtn");
    const minusBtn = document.getElementById("minusBtn");
    const qtyInput = document.getElementById("qtyInput");

    const MIN_QTY = 1;
    const MAX_QTY = 99; 

    if (plusBtn && minusBtn && qtyInput) {
        
        const getValidQty = () => {
            let value = parseInt(qtyInput.value, 10);
            return isNaN(value) ? MIN_QTY : value;
        };

        plusBtn.addEventListener("click", () => {
            const currentQty = getValidQty();
            if (currentQty < MAX_QTY) {
                qtyInput.value = currentQty + 1;
            } else {
                alert(`Maximum limit of ${MAX_QTY} reached.`);
            }
        });

        minusBtn.addEventListener("click", () => {
            const currentQty = getValidQty();
            if (currentQty > MIN_QTY) {
                qtyInput.value = currentQty - 1;
            }
        });

        
        qtyInput.addEventListener("blur", () => {
            let currentQty = getValidQty();
            if (currentQty < MIN_QTY) currentQty = MIN_QTY;
            if (currentQty > MAX_QTY) currentQty = MAX_QTY;
            qtyInput.value = currentQty;
        });
    }

    
    // 3. PLACE ORDER BUTTON
    
    const placeOrderBtn = document.querySelector('.place-order-btn');

    if (placeOrderBtn) {
        placeOrderBtn.addEventListener('click', function() {
            
            this.disabled = true;
            this.textContent = 'Processing...';

            
            setTimeout(() => {
                alert('Order Successful!');
                
            }, 1000);
        });
    }
});